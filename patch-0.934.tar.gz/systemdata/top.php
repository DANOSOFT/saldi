<?
// ---------------------------------------------systemdata/top.php-------patch0.934--------------------
// LICENS
//
// Dette program er fri software. Du kan gendistribuere det og / eller
// modificere det under betingelserne i GNU General Public License (GPL)
// som er udgivet af The Free Software Foundation; enten i version 2
// af denne licens eller en senere version efter eget valg
//
// Dette program er udgivet med haab om at det vil vaere til gavn,
// men UDEN NOGEN FORM FOR REKLAMATIONSRET ELLER GARANTI. Se
// GNU General Public Licensen for flere detaljer.
//
// En dansk oversaettelse af licensen kan laeses her:
// http://www.fundanemt.com/gpl_da.html
//
// Copyright (c) 2004-2005 ITz ApS
// ----------------------------------------------------------------------
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><title>SQL-Finans - Brugerdata</title><meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"></head>
<body bgcolor="#ffffff" link="#000000" vlink="#000000" alink="#000000" center="">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0"><tbody>
  <tr><td align="center" valign="top">
    <table width="100%" align="center" border="1" cellspacing="0" cellpadding="0"><tbody><td>
      <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0"><tbody>
      <td width="25%" bgcolor="<? echo $bgcolor2 ?>"><? echo $font ?><small><a href=../includes/luk.php  accesskey=T>Tilbage</a></small></td>
      <td width="50%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small>Indstillinger</small></td>
      <td width="25%" bgcolor="<? echo $bgcolor2 ?>" align = "right"><? echo $font ?><small><br></small></td>
      </tbody></table></td>
    </tbody></table>
  </td></tr>
  <tr><td align="center" valign="top">
    <table align="center" border="2" cellspacing="2" cellpadding="2"><tbody>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=syssetup.php?valg=moms accesskey=M>Moms</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=syssetup.php?valg=debitor accesskey=D>Deb/kred grp</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=syssetup.php?valg=afdelinger accesskey=A>Afdelinger</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=syssetup.php?valg=lagre accesskey=L>Lagre</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=syssetup.php?valg=varer accesskey=V>Varegrp</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=brugere.php accesskey=B>Brugere</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a href=regnskabsaar.php accesskey=R>Regnskabs&aring;r</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a  href=stamkort.php accesskey=S>Stamdata</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><? echo $font ?><small><a  href=formularkort.php?valg=formularer accesskey=F>Formularer</small></td>
    </tbody></table>
  </td></tr>
<tr><td align = center valign = top height=80%>
