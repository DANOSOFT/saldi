<?

// ----------------------------------------------------------------------050817----------
// LICENS
//
// Dette program er fri software. Du kan gendistribuere det og / eller
// modificere det under betingelserne i GNU General Public License (GPL)
// som er udgivet af The Free Software Foundation; enten i version 2
// af denne licens eller en senere version efter eget valg
//
// Dette program er udgivet med haab om at det vil vaere til gavn,
// men UDEN NOGEN FORM FOR REKLAMATIONSRET ELLER GARANTI. Se
// GNU General Public Licensen for flere detaljer.
//
// En dansk oversaettelse af licensen kan laeses her:
// http://www.fundanemt.com/gpl_da.html
//
// Copyright (c) 2004-2005 ITz ApS
// ----------------------------------------------------------------------

  @session_start();
  $s_id=session_id();

  $modulnr=6;

    include("../includes/connect.php");
    include("../includes/online.php");
    include("../includes/dkdecimal.php");
    include("../includes/usdecimal.php");
    include("../includes/db_query.php");

  $id = $_GET['id'];
  if($_GET['returside'])
  {
    $returside= $_GET['returside'];
    $ordre_id = $_GET['ordre_id'];
    $fokus = $_GET['fokus'];
  }
  else {$returside="debitor.php";}


if ($HTTP_POST_VARS)
{
  $submit=addslashes(trim($HTTP_POST_VARS['submit']));
  $id=$HTTP_POST_VARS['id'];
  $kontonr=addslashes(trim($HTTP_POST_VARS['kontonr']));
  $firmanavn=addslashes(trim($HTTP_POST_VARS['firmanavn']));
  $addr1=addslashes(trim($HTTP_POST_VARS['addr1']));
  $addr2=addslashes(trim($HTTP_POST_VARS['addr2']));
  $postnr=addslashes(trim($HTTP_POST_VARS['postnr']));
  $bynavn=addslashes(trim($HTTP_POST_VARS['bynavn']));
  $land=addslashes(trim($HTTP_POST_VARS['land']));
  $kontakt=addslashes(trim($HTTP_POST_VARS['kontakt']));
  $tlf=addslashes(trim($HTTP_POST_VARS['tlf']));
  $fax=addslashes(trim($HTTP_POST_VARS['fax']));
  $email=addslashes(trim($HTTP_POST_VARS['email']));
  $web=addslashes(trim($HTTP_POST_VARS['web']));
  $betalingsbet=addslashes(trim($HTTP_POST_VARS[betalingsbet]));
  $cvrnr=addslashes(trim($HTTP_POST_VARS['cvrnr']));
  $ean=addslashes(trim($HTTP_POST_VARS['ean']));
  $institution=addslashes(trim($HTTP_POST_VARS['institution']));
  $betalingsdage=$HTTP_POST_VARS['betalingsdage'];
  $kreditmax=usdecimal($HTTP_POST_VARS['kreditmax']);
  list ($gruppe) = split (':', $HTTP_POST_VARS['gruppe']);
  $notes=addslashes(trim($HTTP_POST_VARS['notes']));
  $ordre_id=$HTTP_POST_VARS['ordre_id'];
  $returside=$HTTP_POST_VARS['returside'];
  $fokus=$HTTP_POST_VARS['fokus'];
  $posnr=$HTTP_POST_VARS['posnr'];
  $ans_id=$HTTP_POST_VARS['ans_id'];
  $ans_ant=$HTTP_POST_VARS['ans_ant'];

  
  ######### Tjekker om kontonr er integer
  
  $temp=str_replace(" ","",$kontonr);
  $tmp2='';
  for ($x=0; $x<strlen($temp); $x++)
  {
    $y=substr($temp,$x,1);
    if ((ord($y)<48)||(ord($y)>57)) {$y=0;}
    $tmp2=$tmp2.$y;
  }
  $tmp2=$tmp2*1;
  if ($tmp2!=$kontonr) {print "<BODY onLoad=\"javascript:alert('Kontonummer m&aring; kun best&aring; af heltal uden mellemrum')\">";}
  $kontonr=$tmp2;
  
  
  ## Tildeler aut kontonr hvis det ikke er angivet
  if (($firmanavn)&& ($kontonr < 1))
  {
    $query = db_select("select kontonr from adresser where art = 'D' order by kontonr desc");
    if ($row = db_fetch_array($query)) $kontonr=$row[kontonr]+1;
    else $kontonr=1;
    print "<BODY onLoad=\"javascript:alert('Kontonummer tildelt automatisk')\">";
  
 }
  
 ############################
  
  
  if ($submit=="Slet") {db_modify("delete from adresser where id = $id");}
  else
  {
    if(!$betalingsdage){$betalingsdage=0;}
    if(!$kreditmax){$kreditmax=0;}
    if ($id==0)
    {
      $query = db_select("select id from adresser where kontonr = '$kontonr' and art = 'D'");
      $row = db_fetch_array($query);
      if ($row[id])
      {
        print "<BODY onLoad=\"javascript:alert('Der findes allerede en debitor med Kundenr: $kontonr')\">";
        $id=0;
      }
      elseif($kontonr)
      {
        db_modify("insert into adresser (kontonr, firmanavn, addr1, addr2, postnr, bynavn, land, kontakt, tlf, fax, email, web, betalingsdage, kreditmax, betalingsbet, cvrnr, ean, institution, notes, art, gruppe) values ('$kontonr', '$firmanavn', '$addr1', '$addr2', '$postnr', '$bynavn', '$land', '$kontakt', '$tlf', '$fax', '$email', '$web', '$betalingsdage', '$kreditmax', '$betalingsbet', '$cvrnr', '$ean', '$institution', '$notes', 'D', $gruppe)");
        $query = db_select("select id from adresser where kontonr = '$kontonr' and art = 'D'");
        $row = db_fetch_array($query);
        $id = $row[id];
      }
    }
    elseif ($id > 0)
    {
      db_modify("update adresser set kontonr = '$kontonr',  firmanavn = '$firmanavn', addr1 = '$addr1', addr2 = '$addr2', postnr = '$postnr', bynavn = '$bynavn', land = '$land', kontakt = '$kontakt', tlf = '$tlf', fax = '$fax', email = '$email', web = '$web', betalingsdage= '$betalingsdage', kreditmax = '$kreditmax', betalingsbet = '$betalingsbet', cvrnr = '$cvrnr', ean = '$ean', institution = '$institution', notes = '$notes', gruppe = '$gruppe' where id = '$id'");
      for ($x=1; $x<=$ans_ant; $x++)
      {
        $y=addslashes(trim($posnr[$x]));
        if (($y)&&($y!="-")&&($ans_id[$x])){db_modify("update ansatte set posnr = '$y' where id = '$ans_id[$x]'");}
        elseif (($y=="-")&&($ans_id[$x])){db_modify("delete from ansatte  where id = '$ans_id[$x]'");}
        else {print "<BODY onLoad=\"javascript:alert('Hint!  Du skal s&aelig;tte et - (minus) som pos nr for at slette en kontaktperson')\">";}
      }
    }
  } 
}

print "<table width=\"100%\" height=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tbody>";
print "<tr><td align=\"center\" valign=\"top\">";
print "<table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tbody>";
print "<td width=\"25%\" bgcolor=\"$bgcolor2\"><font face=\"Helvetica, Arial, sans-serif\" color=\"#000066\"><small><a href=$returside?returside=$returside&id=$ordre_id&fokus=$fokus&konto_id=$id accesskey=T>Tilbage</a></small></td>";
print "<td width=\"50%\" bgcolor=\"$bgcolor2\" align=\"center\"><font face=\"Helvetica, Arial, sans-serif\" color=\"#000066\"><small>Debitorkort</small></td>";
print "<td width=\"25%\" bgcolor=\"$bgcolor2\" align = \"right\"><font face=\"Helvetica, Arial, sans-serif\" color=\"#000066\"><small><a href=debitorkort.php?returside=$returside&ordre_id=$ordre_id&fokus=$fokus&konto_id=$id accesskey=N>Ny</a><br></small></td>";
print "</tbody></table>";
print "</td></tr>";
print "<td align = center valign = center>";
print "<table cellpadding=\"1\" cellspacing=\"1\" border=\"0\"><tbody>";

if ($id > 0)
{
  $query = db_select("select * from adresser where id = '$id'");
  $row = db_fetch_array($query);
  $kontonr=trim($row['kontonr']);
  $firmanavn=stripslashes(htmlentities(trim($row['firmanavn'])));
  $addr1=stripslashes(htmlentities(trim($row['addr1'])));
  $addr2=stripslashes(htmlentities(trim($row['addr2'])));
  $postnr=trim($row['postnr']);
  $bynavn=stripslashes(htmlentities(trim($row['bynavn'])));
  $land=stripslashes(htmlentities(trim($row['land'])));
  $kontakt=stripslashes(htmlentities(trim($row['kontakt'])));
  $tlf=trim($row['tlf']);
  $fax=trim($row['fax']);
  $email=trim($row['email']);
  $web=trim($row['web']);
  $kreditmax=$row['kreditmax'];
  $betalingsdage=$row['betalingsdage'];
  $betalingsbet=trim($row['betalingsbet']);
  $cvrnr=trim($row['cvrnr']);
  $ean=trim($row['ean']);
  $institution=stripslashes(htmlentities(trim($row['institution'])));
  $notes=stripslashes(htmlentities(trim($row['notes'])));
  $gruppe=trim($row['gruppe']);
}
else
{
  $id=0;
  $betalingsdage=8;
  $betalingsbet="Netto";
}
$kreditmax=dkdecimal($kreditmax);
print "<form name=debitorkort action=debitorkort.php method=post>";
print "<input type=hidden name=id value='$id'>";
print "<input type=hidden name=ordre_id value='$ordre_id'>";
print "<input type=hidden name=returside value='$returside'>";
print "<input type=hidden name=fokus value='$fokus'>";

print "<tr><td>$font Kundenr</td><td><br></td><td><input type=text size=25 name=kontonr value=\"$kontonr\"></td>";
print "<td width = 20%><br></td>";
print "<td>$font Navn</td><td><br></td><td><input type=text size=25 name=firmanavn value=\"$firmanavn\"></td></tr>";
print "<tr><td>$font Adresse</td><td><br></td><td><input type=text size=25 name=addr1 value=\"$addr1\"></td>";
print "<td><br></td>";
print "<td>$font Adresse2</td><td><br></td><td><input type=text size=25 name=addr2 value=\"$addr2\"></td></tr>";
print "<tr><td>$font Postnr</td><td><br></td><td><input type=text size=6 name=postnr value=\"$postnr\"></td>";
print "<td><br></td>";
print "<td>$font By</td><td><br></td><td><input type=text size=25 name=bynavn value=\"$bynavn\"></td></tr>";
print "<tr><td>$font Land</td><td><br></td><td><input type=text size=25 name=land value=\"$land\"></td>";
print "<td><br></td>";
print "<td>$font EAN - nr.</td><td><br></td><td><input type=text size=10 name=ean value=\"$ean\"></td></tr>";
if ($tlf) {print "<td><A HREF=\"http://www.cvr.dk/soeg_i_cvr/cvrsoegoverview.asp?navn=&kommunekode=&vejnavn=&husnr=&postnr=&Telefon=$tlf&Fax=&EPost=&tjek=yes&produktion=s%F8g\" target=\"_blank\">$font CVR.</A> nr.</td>  ";}
else {print "<td>$font CVR. nr.</td>";}
print "<td><br></td><td><input type=text size=10 name=cvrnr value=\"$cvrnr\"></td>";
print "<td><br></td>";
print "<td>$font Institutionsnr.</td><td><br></td><td><input type=text size=10 name=institution value=\"$institution\"></td></tr>";
print "<tr><td>$font Telefon</td><td><br></td><td><input type=text size=10 name=tlf value=\"$tlf\"></td>";
print "<td><br></td>";
print "<td>$font Telefax</td><td><br></td><td><input type=text size=10 name=fax value=\"$fax\"></td></tr>";
print "<tr><td>$font e-mail</td><td><br></td><td><input type=text size=25 name=email value=\"$email\"></td>";
print "<td><br></td>";
print "<td>$font Hjemmeside</td><td><br></td><td><input type=text size=25 name=web value=\"$web\"></td></tr>";
print "<tr><td>$font Betalingsbetingelse</td><td><br></td>";
print "<td><SELECT NAME=betalingsbet value=$betalingsbet>";
print "<option>$betalingsbet</option>";
if ($betalingsbet!='Efterkrav'){print "<option>Efterkrav</option>";}
else {$betalingsdage="";}
if ($betalingsbet!='Netto'){print "<option>Netto</option>";}
if ($betalingsbet!='Lb. md.'){print "<option>Lb. md.</option>";}
print "</SELECT>&nbsp;+&nbsp;<input type=text size=2 name=betalingsdage value=\"$betalingsdage\"></td>";
print "<td><br></td>";
print "<td>$font Kreditmax</td><td><br></td><td><input type=text size=10 name=kreditmax value=\"$kreditmax\"></td></tr>";
print "<tr><td>$font Debitorgruppe</td><td>";
if (!$gruppe) {$gruppe=1;}
$query = db_select("select beskrivelse from grupper where art='DG' and kodenr='$gruppe'");
$row = db_fetch_array($query);
print "<td><SELECT NAME=gruppe value=\"$gruppe\">";
print "<option>$gruppe:$row[beskrivelse]</option>";
$query = db_select("select * from grupper where art='DG' and kodenr!='$gruppe' order by kodenr");
while ($row = db_fetch_array($query))
{
    print "<option>$row[kodenr]:$row[beskrivelse]</option>";
}
print "</SELECT></td>";
print "<tr><td valign=top>$font Bem&aelig;rkning</td><td colspan=7><textarea name=\"notes\" rows=\"3\" cols=\"85\">$notes</textarea></td></tr>";
#print "<tr><td>$font <a href=ansatte.php?returside=$returside&ordre_id=$ordre_id&fokus=$fokus&konto_id=$id>Kontaktperson</a></td><td><br></td>";
if ($id)
{
  print "<tr><td></td><td></td><td>$font Pos. Kontakt</td><td>$font Lokalnr. / Mobil</td><td>$font E-mail</td><td>$font <a href=ansatte.php?returside=$returside&ordre_id=$ordre_id&fokus=$fokus&konto_id=$id>Ny</a></td></tr>";
  $x=0;
  $query = db_select("select * from ansatte where konto_id = '$id' order by posnr");
  while ($row = db_fetch_array($query))
  {
    $x++;
    if ($x > 0) {print "<tr><td><br></td><td><br></td>";
  }
  print "<td><input type=text size=1 name=posnr[$x] value=\"$x\">$font &nbsp;<a href=ansatte.php?returside=$returside&ordre_id=$ordre_id&fokus=$fokus&konto_id=$id&id=$row[id]>".stripslashes(htmlentities($row[navn]))."</a></td>";
  print "<td>$font $row[tlf] / $row[mobil]</td><td>$font $row[email]</td></tr>";
  print "<input type=hidden name=ans_id[$x] value=$row[id]>";
}
print "<input type=hidden name=ans_ant value=$x>";

print "<tr><td><br></td></tr>";
}
print "<tr><td><br></td></tr>";

$query = db_select("select id from openpost where konto_id = '$id'");
if (db_fetch_array($query)) {$slet="NO";}
$query = db_select("select id from ordrer where konto_id = '$id'");
if (db_fetch_array($query)) {$slet="NO";}
$query = db_select("select id from ansatte where konto_id = '$id'");
if (db_fetch_array($query)) {$slet="NO";}
     
if ($slet=="NO") {print "<td><br></td><td><br></td><td><br></td><td align = center><input type=submit accesskey=\"g\" value=\"Gem / opdater\" name=\"submit\"></td>";}     
else {print "<td><br></td><td><br><td align = center><input type=submit accesskey=\"g\" value=\"Gem / opdater\" name=\"submit\"></td><td><br></td><td><input type=submit accesskey=\"s\" value=\"Slet\" name=\"submit\"></td>";}
 
 
?>
</tbody>
</table>
</td></tr>
<tr><td align = "center" valign = "bottom">
    <table width="100%" align="center" border="1" cellspacing="0" cellpadding="0"><tbody>
      <td width="100%" bgcolor="<? print $bgcolor2 ?>"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><br></small></td>
    </tbody></table>
</td></tr>
</tbody></table>
</body></html>
