Saldi Read Me file
========================

Saldi is a free software accounting system in Danish. No English 
documentation.

If you understand Danish then please read the file LAESMIG.txt.  
