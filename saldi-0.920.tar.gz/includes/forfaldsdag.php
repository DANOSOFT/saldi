<?
include("../includes/dkdato.php");
  
if (!function_exists('forfaldsdag'))
{ 
  function forfaldsdag($fakturadate, $betalingsbet, $betalingsdage)
  {
    list($faktaar, $faktmd, $faktdag) = split("-", $fakturadate);
    $forfaldsaar=$faktaar; 
    $forfaldsmd=$faktmd;
    $forfaldsdag=$faktdag;
    $slutdag=31;

    if (($fakturadate)&&($betalingsbet!="Efterkrav")) 
    {
      while (!checkdate($forfaldsmd, $slutdag, $forfaldsaar))
      {
        $slutdag--;
        if ($slutdag<27) {break;}
      }
      if ($betalingsbet!="Netto"){$forfaldsdag=$slutdag;} # Saa maa det vaere lb. md
      $forfaldsdag=$forfaldsdag+$betalingsdage;
      while ($forfaldsdag>$slutdag)
      {
        $forfaldsmd++;
        if ($forfaldsmd>12)
        {
          $forfaldsaar++;
          $fortfaldsmd=1;
        }
        $forfaldsdag=$forfaldsdag-$slutdag;
        $slutdag=31;
        while (!checkdate($forfaldsmd, $slutdag, $forfaldsaar))
        {
          $slutdag--;
          if ($slutdag<27) {break;}
        }
      }     
    }
    return(dkdato($forfaldsaar."-".$forfaldsmd."-".$forfaldsdag));
  }
}
?>