<?
  @session_start();
  $s_id=session_id();
// ----------------------------------------------------------------------
// LICENS
//
// Dette program er fri software. Du kan gendistribuere det og / eller
// modificere det under betingelserne i GNU General Public License (GPL)
// som er udgivet af "The Free Software Foundation", enten i version 2
// af denne licens eller en senere version, efter eget valg.
//
// Dette program er udgivet med haab om at det vil vaere til gavn,
// men UDEN NOGEN FORM FOR REKLAMATIONSRET ELLER GARANTI. Se
// GNU General Public Licensen for flere detaljer.
//
// En dansk oversaetelse af licensen kan laeses her:
// http://www.fundanemt.com/gpl_da.html
// ----------------------------------------------------------------------

  include("../includes/connect.php");
  include("../includes/online.php");
  include("../includes/usdate.php");
  include("../includes/dkdecimal.php");
  include("../includes/db_query.php");

  $id=$_GET['id'];
  
  ?>
    <script language="JavaScript">
    <!--
    function fejltekst(tekst)
    {
      alert(tekst);
      window.location.replace("ordre.php?id=<?echo $id?>");
    }
-->
</script>
<?

  $query = db_select("select levdate, status from ordrer where id = $id");
  $row = db_fetch_array($query);
  if ($row[status]>2)
  {
    print "<BODY onLoad=\"fejltekst('Hmmm - har du brugt browserens opdater eller tilbageknap???')\">";
   #  print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
    exit;
  }

  $id=$_GET['id'];

  $query = db_select("select box1, box2, box3, box4 from grupper where art='RA' and kodenr='$regnaar'");
  if ($row = db_fetch_array($query))
  {
    $year=substr(str_replace(" ","",$row['box2']),-2);
    $aarstart=str_replace(" ","",$year.$row['box1']);
    $year=substr(str_replace(" ","",$row['box4']),-2);
    $aarslut=str_replace(" ","",$year.$row['box3']);
  }

  $query = db_select("select * from ordrer where id = '$id'");
  $row = db_fetch_array($query);
  $art=$row[art];
  $kred_ord_id=$row[kred_ord_id];
#  if ($row[status]>=2)
#  {
#    print "Hov hov du - du har bogf&oslash;rt den en gang";
#    print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
#    exit;
#  }
  if (!$row[levdate])
  {
    print "<BODY onLoad=\"fejltekst('Leveringsdato ikke udfyldt')\">";
   #  print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
    exit;
  }
  else
  {
    transaktion("begin");
    $fejl=0;
    if ($row[levdate]<$row[ordredate])
    {
      print "<BODY onLoad=\"fejltekst('Leveringsdato er f&oslash;r ordredato')\">";
     #  print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
      exit;
    }
    $levdate=$row[levdate];
    list ($year, $month, $day) = split ('-', $row[levdate]);
    $year=substr($year,-2);
    $ym=$year.$month;
    if (($ym<$aarstart)||($ym>$aarslut))
    {
      print "<BODY onLoad=\"fejltekst('Leveringsdato udenfor regnskabs&aring;r')\">";
     #  print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
      exit;
    }
    if ($fejl==0)
    {
      $x=0;
      $query = db_select("select * from ordrelinjer where ordre_id = '$id'");
      while ($row = db_fetch_array($query))
      {
        if (($row[posnr]>0)&&(strlen(trim(($row['varenr'])))>0))
        {
          $x++;
          $linje_id[$x]=$row['id'];
          $varenr[$x]=$row['varenr'];
          $vare_id[$x]=$row['vare_id'];
          $leveres[$x]=$row['leveres'];
          $pris[$x]=$row['pris']-($row['pris']*$row['rabat']/100);
          $serienr[$x]=trim($row['serienr']);
        }
      }
      $linjeantal=$x;
      for ($x=1; $x<=$linjeantal; $x++)
      {
        if (($leveres[$x]>0)&&($serienr[$x])&&($art!='KK'))
        {
          $sn_antal[$x]=0; 
          $query = db_select("select * from serienr where kobslinje_id = '$linje_id[$x]' and batch_kob_id=0");
          while ($row = db_fetch_array($query))
          {
            $sn_antal[$x]=$sn_antal[$x]+1000;
            $y=$sn_antal[$x]+$x;
            $sn_id[$y]=$row[id];
          }
          if ($leveres[$x]>$sn_antal[$x]/1000)
          {
             print "<BODY onLoad=\"fejltekst('Serienumre ikke udfyldt')\">";
#             print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
             exit;
          }
        }
        if ((($leveres[$x]<0)&&($serienr[$x]))||(($leveres[$x]>0)&&($serienr[$x])&&($art=='KK')))
        {
          $sn_antal[$x]=0; 
          $query = db_select("select * from serienr where salgslinje_id = '$linje_id[$x]' and batch_salg_id=0");
          while ($row = db_fetch_array($query))
          {
            $sn_antal[$x]=$sn_antal[$x]+1000;
            $y=$sn_antal[$x]+$x;
            $sn_id[$y]=$row[id];
          }
          if ((($leveres[$x]<$sn_antal[$x]/-1000)&&($art!='KK'))||(($leveres[$x]>$sn_antal[$x]/1000)&&($art=='KK')))
          {
             print "<BODY onLoad=\"fejltekst('Serienumre ikke valgt')\">";
#             print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";
             exit;
          }
        }
      }
      for ($x=1; $x<=$linjeantal; $x++)
      {
        $sn_start=0;
        $query = db_select("select id, gruppe, beholdning from varer where varenr='$varenr[$x]'");
        $row = db_fetch_array($query);
        $vare_id[$x]=$row[id];
        $gruppe[$x]=$row[gruppe];
        if ($row[beholdning]) {$beholdning=$row[beholdning];}
        else {$beholdning=0;}
        if ($art=='KK'){$beholdning=$beholdning-$leveres[$x];}
        else {$beholdning=$beholdning+$leveres[$x];}
        if (($vare_id[$x])&&($leveres[$x]!=0))
        {
          $query = db_select("select * from grupper where art='VG' and kodenr='$gruppe[$x]'");
          $row = db_fetch_array($query);
          $box1=trim($row[box1]); $box2=trim($row[box2]); $box3=trim($row[box3]); $box4=trim($row[box4]); $box8=trim($row[box8]);
          if ($box8!='on')  # Dvs varen er IKKE lagerfoert.
          {
            db_modify("update ordrelinjer set bogf_konto=$box4 where id='$linje_id[$x]'");
            db_modify("insert into batch_kob(vare_id, linje_id, kobsdate, ordre_id, antal, pris) values ($vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x], '$pris[$x]')");
          }
          else #hvis varen ER lagerfoert
          {
            db_modify("update varer set beholdning=$beholdning where id=$vare_id[$x]");
            if ($art=='KK') # Hvis der er tale om en kreditnota 
            {
              $rest=$leveres[$x]*-1;
              $leveres[$x];
              $y=0;
              $query = db_select("select * from batch_kob where vare_id=$vare_id[$x] and ordre_id = '$kred_ord_id' and pris = $pris[$x] and antal <= '$leveres[$x]'");
              if ($row = db_fetch_array($query))
              {
                $batch_id=$row[id];
                $batch_antal=$row[antal];
                $batch_rest=$row[rest];
                $batch_pris=$row['pris'];
                if (($batch_rest+$rest>0))
                {
                  $batch_rest=$batch_rest+$rest;
                  db_modify("update batch_kob set rest=$batch_rest where id=$batch_id");
                  $rest=$rest+$batch_rest;
                  db_modify("insert into batch_salg(batch_kob_id, vare_id, linje_id, salgsdate, ordre_id, antal, pris) values ($batch_id, $vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x]+$rest, '$batch_pris')");
                 if ($serienr[$x]) { 
                   for ($y=1; $y<=$leveres[$x]+$rest; $y++) {
                      $sn_start=$sn_start+1000;
                      $z=$sn_start+$x;
                      db_modify("update serienr set batch_salg_id=$batch_id where id=$sn_id[$z]");
                    }
                  $sn_start=$y;
                  }   
                } 
                elseif($rest<0)
                {
                  db_modify("update batch_kob set rest=0 where id=$batch_id");
                  $rest=$rest+$batch_rest;
                  db_modify("insert into batch_salg(batch_kob_id, vare_id, linje_id, salgsdate, ordre_id, antal, pris) values ($batch_id, $vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x]+$rest, '$batch_pris')");
                  if ($serienr[$x]) { 
                    for ($y=1; $y<=$leveres[$x]+$rest; $y++) {
                      $sn_start=$sn_start+1000;
                      $z=$sn_start+$x;
                      db_modify("update serienr set batch_salg_id=$batch_id where id=$sn_id[$z]");
                    }
                  $sn_start=$y;
                  }  
                }
              }
              else
              {
                $query = db_select("select * from batch_kob where vare_id=$vare_id[$x] and ordre_id = $kred_ord_id");
                while ($row = db_fetch_array($query))
                {
                  $batch_id=$row[id];
                  $batch_antal=$row[antal];
                  $batch_rest=$row[rest];
                  $batch_pris=$row['pris'];
                  if (($batch_rest+$rest>0))
                  {
                    $batch_rest=$batch_rest+$rest;
                    db_modify("update batch_kob set rest=$batch_rest where id=$batch_id");
                    $rest=$rest+$batch_rest;
                    db_modify("insert into batch_salg(batch_kob_id, vare_id, linje_id, salgsdate, ordre_id, antal, pris) values ($batch_id, $vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x]+$rest, '$batch_pris')");
                    if ($serienr[$x]) { 
                      for ($y=1; $y<=$leveres[$x]+$rest; $y++)
                      {
                        $sn_start=$sn_start+1000;
                        $z=$sn_start+$x;
                        db_modify("update serienr set batch_salg_id=$batch_id where id=$sn_id[$z]");
                      }
                      $sn_start=$y;
                    }  
                  }
                  elseif($rest<0)
                  {
                    db_modify("update batch_kob set rest=0 where id=$batch_id");
                    $rest=$rest+$batch_rest;
                    db_modify("insert into batch_salg(batch_kob_id, vare_id, linje_id, salgsdate, ordre_id, antal, pris) values ($batch_id, $vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x]+$rest, '$batch_pris')");
                    if ($serienr[$x]) { 
                      for ($y=1; $y<=$leveres[$x]+$rest; $y++)
                      {
                        $sn_start=$sn_start+1000;
                        $z=$sn_start+$x;
                        db_modify("update serienr set batch_salg_id=$batch_id where id=$sn_id[$z]");
                      }
                      $sn_start=$y;
                    } 
                  }
                }
              }
            }
            elseif ($leveres[$x]<0) #Varereturnering
            {
              $rest=$leveres[$x];
              $leveres[$x]=$leveres[$x]*-1;
              $y=0;
              $query = db_select("select * from batch_kob where vare_id=$vare_id[$x] and rest>0 order by kobsdate");
              while ($row = db_fetch_array($query))
              {
                $batch_id=$row[id];
                $batch_antal=$row[antal];
                $batch_rest=$row[rest];
                $batch_pris=$row['pris'];
                if (($batch_rest+$rest>0))
                {
                  $batch_rest=$batch_rest+$rest;
                  db_modify("update batch_kob set rest=$batch_rest where id=$batch_id");
                  $rest=$rest+$batch_rest;
#exit;    
                  db_modify("insert into batch_salg(batch_kob_id, vare_id, linje_id, salgsdate, ordre_id, antal, pris) values ($batch_id, $vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x]+$rest, '$batch_pris')");
                  
                  for ($y=1; $y<=$leveres[$x]+$rest; $y++)
                  {
                    $sn_start=$sn_start+1000;
                    $z=$sn_start+$x;
                    db_modify("update serienr set batch_salg_id=$batch_id where id=$sn_id[$z]");
                  }
                  $sn_start=$y;
                }
                elseif($rest<0)
                {
                  db_modify("update batch_kob set rest=0 where id=$batch_id");
                  $rest=$rest+$batch_rest;
                  db_modify("insert into batch_salg(batch_kob_id, vare_id, linje_id, salgsdate, ordre_id, antal, pris) values ($batch_id, $vare_id[$x], $linje_id[$x], '$levdate', $id, $leveres[$x]+$rest, '$batch_pris')");
                  for ($y=1; $y<=$leveres[$x]+$rest; $y++)
                  {
                    $sn_start=$sn_start+1000;
                    $z=$sn_start+$x;
                    db_modify("update serienr set batch_salg_id=$batch_id where id=$sn_id[$z]");
                  }
                  $sn_start=$y;
                
                }
              }
            }
            elseif ($beholdning-$leveres[$x]>=0) {
             $query = db_select("select antal from reservation where linje_id=$linje_id[$x] and batch_salg_id<0");
              if ($row = db_fetch_array($query)) {}
              else {
                db_modify("insert into batch_kob(kobsdate, vare_id, linje_id, ordre_id, antal, rest) values ('$levdate', $vare_id[$x], $linje_id[$x], $id, $leveres[$x], $leveres[$x])");
                if ($serienr[$x]) {
                  $query = db_select("select id from batch_kob where kobsdate='$levdate' and vare_id=$vare_id[$x] and linje_id=$linje_id[$x] and ordre_id=$id and antal=$leveres[$x] and rest=$leveres[$x] order by id desc");
                  $row = db_fetch_array($query);
                  $batch_id=$row[id];
                  for ($y=1; $y<=$leveres[$x]; $y++) {
                      $sn_start=$sn_start+1000;
                      $z=$sn_start+$x;
                    db_modify("update serienr set batch_kob_id=$batch_id where id=$sn_id[$z]");
                  }
                }
                db_modify("delete from reservation where linje_id=$linje_id[$x]");
              }
            }
            else  {
              $res_antal=0;
              $query = db_select("select antal from reservation where linje_id=$linje_id[$x] and batch_salg_id<0");
              while ($row = db_fetch_array($query)) {$res_antal=$res_antal+$row[antal];} 
              if ($leveres[$x]<$res_antal) {
                print "<BODY onLoad=\"fejltekst('Der er reserveret flere varer end der modtages - foretag proiritering')\">";
                exit;
              }
              $res_antal=0;
              $query = db_select("select batch_kob_id, antal from reservation where linje_id=$linje_id[$x] and batch_salg_id=0");
              $row = db_fetch_array($query);
              $batch_id=$row[batch_kob_id];
              $res_antal=$row[antal];
            
            $query = db_select("select * from batch_kob where id=$batch_id");
            if ($row = db_fetch_array($query)) {
              $batch_antal=$row[antal];
              $batch_rest=$row[rest];
              $rest=$leveres[$x]+$batch_rest;

             if ($rest>=0) {
                db_modify("update batch_kob set kobsdate='$levdate', ordre_id=$id, antal=$leveres[$x], rest=$rest where id=$batch_id");
                db_modify("delete from reservation where batch_kob_id=$batch_id"); 
                if ($leveres[$x]!=$res_antal) {
                  db_modify("insert into reservation(linje_id, batch_kob_id, batch_salg_id, antal( values ($linje_id[$x], batch_kob_id[$x], 0, $rest)");
                }
                if ($serienr[$x]) {
                  for ($y=-1; $y>=$batch_rest[$x]; $y--) {
                    $sn_start=$sn_start+1000;
                    $z=$sn_start+$x;
                    db_modify("update serienr set batch_kob_id=$batch_id where id=$sn_id[$z]");
                  }
                  $sn_start=$y;
                }
              }
/*
                if ($rest<0) {
                   db_modify ("update batch_kob set kobsdate='$levdate', linje_id=$linje_id[$x], ordre_id=$id, antal=$leveres[$x], rest=0 where id=$batch_id");
                   for ($y=1; $y<=$leveres[$x]; $y++) {
                     $sn_start=$sn_start+1000;
                     $z=$sn_start+$x;
                     db_modify("update serienr set batch_kob_id=$batch_id where id=$sn_id[$z]");
                   }
                   $sn_start=$y;
                }
                if ($rest!=0) {
                  db_modify("insert into batch_kob(kobsdate, vare_id, linje_id, ordre_id, antal, rest) values ('$levdate', $vare_id[$x], $linje_id[$x], $id, $rest, $rest)");
                  if ($serienr[$x]) {
                    $query = db_select("select id from batch_kob where kobsdate '$levdate' and vare_id=$vare_id[$x] and linje_id=$linje_id[$x] and ordre_id $id and antal=$rest and rest=$rest order by id desc");
                    $row = db_fetch_array($query);
                    $batch_id=$row[id];
                    for ($y=1; $y<=$rest; $y=$y++) {
                      $sn_start=$sn_start+1000;
                      $z=$sn_start+$x;
                      db_modify("update serienr set batch_kob_id=$batch_id where id=$sn_id[$z]");
                    }
                  }
                }
*/
              }  
            }
          }
        }
        db_modify("update ordrelinjer set leveres=0 where id = $linje_id[$x]");
      }
    }
   
     transaktion("commit");
  }
#  print "<a href=ordre.php?id=$id accesskey=T>retur</a>";
  print "<meta http-equiv=\"refresh\" content=\"0;URL=ordre.php?id=$id\">";

?>
</tbody></table>
</td></tr>
</tbody></table>
</body></html>
