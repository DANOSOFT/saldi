<?
// ----------------------------------------------------------------------
// LICENS
//
// Dette program er fri software. Du kan gendistribuere det og / eller
// modificere det under betingelserne i GNU General Public License (GPL)
// som er udgivet af The Free Software Foundation; enten i version 2
// af denne licens eller en senere version efter eget valg
//
// Dette program er udgivet med haab om at det vil vaere til gavn,
// men UDEN NOGEN FORM FOR REKLAMATIONSRET ELLER GARANTI. Se
// GNU General Public Licensen for flere detaljer.
//
// En dansk oversaettelse af licensen kan laeses her:
// http://www.fundanemt.com/gpl_da.html
//
// Copyright (c) 2004-2005 ITz ApS
// ----------------------------------------------------------------------

include("../includes/connect.php");
include("../includes/online.php");
include("../includes/db_query.php");


#$fp=fopen("gruppeopret.txt","a");
$query = db_select("select * from grupper order by kode");
while ($row = db_fetch_array($query))
{
  echo "db_modify("insert INTO grupper (beskrivelse, kode, kodenr, art, box1, box2, box3, box4, box5, box6) values ('".$row[beskrivelse]."', '".$row[kode]."', '".$row[kodenr]."', '".$row[art]."', '".$row[ box1]."', '".$row[box2]."', '".$row[box3]."', '".$row[box4]."', '".$row[box5]."', '".$row[box6]."')\");<br>";
#  fwrite "db_modify("insert INTO grupper (beskrivelse, kode, kodenr, art, box1, box2, box3, box4, box5, box6) values ('".$row[beskrivelse]."', '".$row[kode]."', '".$row[kodenr]."', '".$row[art]."', '".$row[ box1]."', '".$row[box2]."', '".$row[box3]."', '".$row[box4]."', '".$row[box5]."', '".$row[box6]."')\");";
}
fclose($fp);
?>
