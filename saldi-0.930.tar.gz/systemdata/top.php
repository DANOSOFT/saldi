
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><title>SQL-Finans - Brugerdata</title><meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"></head>
<body bgcolor="#ffffff" link="#000000" vlink="#000000" alink="#000000" center="">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0"><tbody>
  <tr><td align="center" valign="top">
    <table width="100%" align="center" border="1" cellspacing="0" cellpadding="0"><tbody><td>
      <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0"><tbody>
      <td width="25%" bgcolor="<? echo $bgcolor2 ?>"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=../includes/luk.php  accesskey=T>Tilbage</a></small></td>
      <td width="50%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small>Indstillinger</small></td>
      <td width="25%" bgcolor="<? echo $bgcolor2 ?>" align = "right"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><br></small></td>
      </tbody></table></td>
    </tbody></table>
  </td></tr>
  <tr><td align="center" valign="top">
    <table align="center" border="2" cellspacing="2" cellpadding="2"><tbody>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=syssetup.php?valg=moms accesskey=M>Moms</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=syssetup.php?valg=debitor accesskey=D>Deb/kred grp</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=syssetup.php?valg=valuta accesskey=V>Valuta</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=syssetup.php?valg=projekt accesskey=P>Projekt</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=syssetup.php?valg=varer accesskey=V>Varegrp</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=brugere.php accesskey=B>Brugere</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a href=regnskabsaar.php accesskey=R>Regnskabs&aring;r</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a  href=stamkort.php accesskey=S>Stamdata</small></td>
      <td width="11.1%" bgcolor="<? echo $bgcolor2 ?>" align="center"><font face="Helvetica, Arial, sans-serif" color="#000066"><small><a  href=formularkort.php?valg=formularer accesskey=F>Formularer</small></td>
    </tbody></table>
  </td></tr>
<tr><td align = center valign = top height=80%>
