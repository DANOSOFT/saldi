<?
// ----------------------------------------------------------------------
// LICENS
//
// Dette program er fri software. Du kan gendistribuere det og / eller
// modificere det under betingelserne i GNU General Public License (GPL)
// som er udgivet af The Free Software Foundation; enten i version 2
// af denne licens eller en senere version efter eget valg
//
// Dette program er udgivet med haab om at det vil vaere til gavn,
// men UDEN NOGEN FORM FOR REKLAMATIONSRET ELLER GARANTI. Se
// GNU General Public Licensen for flere detaljer.
//
// En dansk oversaettelse af licensen kan laeses her:
// http://www.fundanemt.com/gpl_da.html
//
// Copyright (c) 2004-2005 ITz ApS
// ----------------------------------------------------------------------

include("../includes/connect.php");
include("../includes/db_query.php");

$linje='';
$row=0;
$fp=fopen("kontoplan.csv","r");
while (!feof($fp))
{
  $row++;
  $linje[$row]=fgets($fp);
}
fclose($fp);

for($x=1;$x<=$row;$x++)
{
  if ($linje[$x]) {List ($kontonr[$x], $beskrivelse[$x], $kontotype[$x], $katagori[$x], $fra_kto[$x], $til_kto[$x], $moms[$x]) = split (';', $linje[$x]);}
}

$fp=fopen("opretkontoplan.txt","a");
for($x=1;$x<=$row;$x++)
{
  $beskrivelse[$x]=str_replace("\"","",$beskrivelse[$x]);
  $kontotype[$x]=str_replace("\"","",$kontotype[$x]);
  echo "db_modify("insert INTO kontoplan (kontonr, beskrivelse, kontotype, katagori, fra_kto, til_kto, moms) values ('".$kontonr[$x]."', '".$beskrivelse[$x]."', '".$kontotype[$x]."', '".$katagori[$x]."', '".$fra_kto[$x]."', '".$til_kto[$x]."', '".$moms[$x]."')\");<br>";
  fwrite($fp,"db_modify("insert INTO kontoplan (kontonr, beskrivelse, kontotype, katagori, fra_kto, til_kto, moms) values ('".$kontonr[$x]."', '".$beskrivelse[$x]."', '".$kontotype[$x]."', '".$katagori[$x]."', '".$fra_kto[$x]."', '".$til_kto[$x]."', '".$moms[$x]."')\");<br>");
}
fclose($fp);
?>
