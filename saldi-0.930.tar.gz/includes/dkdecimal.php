<?
// ----------------------------------------------------------------------
// LICENS
//
// Dette program er fri software. Du kan gendistribuere det og / eller
// modificere it under betingelserne i GNU General Public License (GPL)
// som er udgivet af The Free Software Foundation; enten i version 2
// af denne licens eller en senere version efter eget valg dog med med
// f�lgende tilf�jelse:
//
// SQL finans m� kun efter skriftelig aftale med ITz ApS anvendes som
// v�rt for andre virksomheders regnskaber.
//
// Dette program er udgivet med h�b om at det vil v�re til gavn,
// men UDEN NOGEN FORM FOR REKLAMATIONSRET ELLER GARANTI. Se
// GNU General Public Licensen for flere detaljer.
//
// En dansk overs�ttelse af licensen kan l�ses her:
// http://www.fundanemt.com/gpl_da.html
// ----------------------------------------------------------------------

function dkdecimal($tal)
{
  $tal = round($tal,2);
  $tal = str_replace(".",",",$tal);
  if (!strstr($tal, ",")) {$tal = $tal . ",00";}
  if (substr($tal,-2,1) == ",") {$tal = $tal . "0";}
  return $tal;
}
?>
